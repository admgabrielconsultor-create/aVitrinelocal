# Testar o Buscou Achou no GitHub (Codespaces)

O GitHub Pages só hospeda arquivos estáticos e este projeto tem backend (FastAPI) e banco (MongoDB).
Por isso o teste roda no **GitHub Codespaces**: um computador na nuvem, já com tudo configurado (`.devcontainer/`).
O plano gratuito do GitHub inclui horas mensais de Codespaces.

## 1. Chaves do login (Clerk) — 5 minutos
1. Crie uma conta em https://clerk.com e um app. Ative **Google** em *User & authentication > Social connections*.
2. Use a instância de **Desenvolvimento** e copie `pk_test_...` e `sk_test_...` (Configure > API keys). Não precisa de domínio nem de Google Cloud.

## 2. Subir para o GitHub
1. Crie um repositório **privado** no GitHub e envie o conteúdo desta pasta (arraste os arquivos em *Add file > Upload files*, ou use `git push`).
2. Nunca envie o arquivo `.env` (ele já está no `.gitignore`).

## 3. Cadastrar os segredos
No repositório: **Settings > Secrets and variables > Codespaces > New repository secret**. Crie 3:
- `CLERK_PUBLISHABLE_KEY` = `pk_test_...`
- `CLERK_SECRET_KEY` = `sk_test_...`
- `ADMIN_EMAIL` = seu e-mail do Google (vira administrador no 1º login)

## 4. Abrir o Codespace
**Code > Codespaces > Create codespace on main.** Na primeira vez leva alguns minutos (instala tudo e compila o site).
Quando terminar, abra a aba **Portas (Ports)**, porta **8001**, e clique no ícone de globo: esse é o site.
O banco já vem com as 6 empresas de exemplo.

## Roteiro de teste
- [ ] A home mostra as empresas de exemplo
- [ ] Entrar com Google (o e-mail do `ADMIN_EMAIL`) e abrir `/admin`
- [ ] Cadastrar uma empresa em `/cadastro-empresa` com outra conta, aprovar no `/admin` e abrir `/painel-empresa`
- [ ] Avaliar uma loja como cliente

## Dicas
- Logs do servidor: `tail -f /tmp/backend.log` no terminal do Codespace.
- Depois de mudar o código do frontend: `cd frontend && npx vite build && rm -rf ../backend/static && cp -r dist ../backend/static`, e reinicie com `bash .devcontainer/start.sh`.
- Se o login falhar, confira se os 3 segredos estão cadastrados e se são as chaves `pk_test`/`sk_test`. Depois de cadastrar ou alterar um segredo, crie o Codespace de novo.
- Para mostrar para outras pessoas, deixe a porta 8001 como **Pública** (botão direito na porta > Visibilidade da porta).
- Quando terminar, pare o Codespace (Code > Codespaces > ⋯ > Stop) para não gastar horas.
- Aba **Actions** do repositório: a verificação automática confirma que o site compila e que o backend carrega a cada envio.

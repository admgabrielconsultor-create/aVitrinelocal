# Testar o Buscou Achou em um host de teste

O projeto agora tem uma **imagem única** (`Dockerfile` na raiz): o FastAPI serve a API e o site React juntos.
Nada muda para a produção na Hostinger (`docker-compose.yml` continua igual).

## O que você precisa (tudo grátis)
1. **MongoDB Atlas** (mongodb.com/atlas): crie um cluster M0, um usuário e libere o acesso de rede `0.0.0.0/0`. Copie a string `mongodb+srv://...`.
2. **Clerk** (clerk.com): crie um app, ative **Google** e use a instância de **Desenvolvimento**. Copie `pk_test_...` e `sk_test_...`. Não precisa de domínio nem de Google Cloud.
3. Um host com Docker. O mais simples: **Render** (render.com).

## Opção A: Render (recomendado)
1. Suba esta pasta para um repositório no GitHub.
2. Render > **New + > Blueprint** > escolha o repositório (ele lê o `render.yaml`).
3. Preencha as 4 variáveis pedidas: `MONGO_URL`, `CLERK_PUBLISHABLE_KEY`, `CLERK_SECRET_KEY`, `ADMIN_EMAIL`.
4. Aguarde o build (alguns minutos). O endereço será `https://buscou-achou-teste.onrender.com`.
   No plano grátis o site "dorme" após inatividade; o primeiro acesso demora cerca de 1 minuto.

Railway, Koyeb e Fly.io funcionam do mesmo jeito: apontam para o `Dockerfile` da raiz e usam as mesmas variáveis (veja `.env.test.example`).

## Opção B: no seu computador
```bash
cp .env.test.example .env      # preencha as chaves do Clerk e ADMIN_EMAIL
docker compose -f docker-compose.test.yml up --build
# abra http://localhost:8080
```
Este modo já inclui um MongoDB local; o `MONGO_URL` do `.env` é ignorado.

## Roteiro de teste
- [ ] Home abre e mostra as 6 empresas de exemplo (`SEED_ON_START=1`)
- [ ] Entrar com Google usando o e-mail de `ADMIN_EMAIL` e abrir `/admin`
- [ ] Cadastrar uma empresa em `/cadastro-empresa` com outra conta, aprovar no `/admin` e ver o painel em `/painel-empresa`
- [ ] Avaliar uma loja como cliente (1 avaliação por loja)

## Problemas comuns
- **Tela em branco / "login indisponível"**: chaves do Clerk faltando ou erradas (use `pk_test`/`sk_test`).
- **Erro de conexão com o banco**: no Atlas, libere o IP `0.0.0.0/0` e confira usuário e senha na string.
- **Admin não aparece**: o e-mail do Google precisa estar **verificado** e igual ao de `ADMIN_EMAIL`. Se já entrou antes com outro papel, apague o usuário na coleção `users`.
- **Logo não carrega**: ela ainda aponta para o endereço da plataforma antiga (veja `DEPLOY-HOSTINGER.md`, seção 6).

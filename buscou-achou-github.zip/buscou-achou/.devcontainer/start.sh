#!/usr/bin/env bash
# Roda a cada vez que o Codespace inicia: sobe o site (API + frontend) na porta 8001.
cd "$(dirname "$0")/../backend"
pkill -f "uvicorn server:app" 2>/dev/null || true
if [ -z "$CLERK_SECRET_KEY" ] || [ -z "$CLERK_PUBLISHABLE_KEY" ]; then
  echo "ATENÇÃO: cadastre CLERK_PUBLISHABLE_KEY, CLERK_SECRET_KEY e ADMIN_EMAIL nos Codespaces secrets (veja LEIA-ME-GITHUB.md)."
fi
STATIC_DIR="$PWD/static" nohup uvicorn server:app --host 0.0.0.0 --port 8001 --proxy-headers --forwarded-allow-ips '*' > /tmp/backend.log 2>&1 &
echo "Site no ar na porta 8001. Logs: tail -f /tmp/backend.log"

#!/usr/bin/env bash
# Roda uma vez, ao criar o Codespace: instala dependências e compila o site.
set -e
pip install --no-cache-dir -r backend/requirements.prod.txt
cd frontend && npm ci && npx vite build
rm -rf ../backend/static && cp -r dist ../backend/static
